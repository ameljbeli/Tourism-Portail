<?php /* Template for default sidebar */ ?>
<aside class="mh-widget-col-1 mh-sidebar">
	<?php dynamic_sidebar('mh-sidebar'); ?>
</aside>