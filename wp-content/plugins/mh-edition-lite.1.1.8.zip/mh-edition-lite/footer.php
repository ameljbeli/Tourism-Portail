<footer class="mh-copyright-wrap">
	<div class="mh-container mh-container-inner clearfix">
		<p class="mh-copyright"><?php printf(__('Copyright %1$s | MH Edition lite WordPress Theme by %2$s', 'mh-edition-lite'), date("Y"), '<a href="' . esc_url('https://www.mhthemes.com/') . '" rel="nofollow">MH Themes</a>'); ?></p>
	</div>
</footer>
</div><!-- .mh-container-outer -->
<?php wp_footer(); ?>
</body>
</html>