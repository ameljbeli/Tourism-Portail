jQuery(document).ready(function($){
    $('.wpcloudy_meta_bg_color_picker').wpColorPicker();
	$('.wpcloudy_meta_txt_color_picker').wpColorPicker();
	$('.wpcloudy_meta_border_color_picker').wpColorPicker();
	
	$('.wpcloudy_admin_color_picker').wpColorPicker();
});