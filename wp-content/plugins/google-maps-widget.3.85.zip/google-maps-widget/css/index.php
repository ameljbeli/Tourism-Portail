<?php
  // Silence is golden.