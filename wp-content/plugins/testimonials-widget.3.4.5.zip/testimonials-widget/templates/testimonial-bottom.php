<?php
global $tw_template_args;

$atts = $tw_template_args['atts'];
?>
<div class="bottom_text"><?php echo $atts['bottom_text']; ?></div>
