# Deprecation Notices - Testimonials Widget

## Deprecated Shortcodes

* `[testimonialswidget_list]` use `[testimonials]` instead as of 2.19.0
* `[testimonialswidget_widget]` use `[testimonials_slider]` instead as of 2.19.0

## Deprecated Theme Functions

* `testimonialswidget_list()` use `testimonials()` instead as of 2.19.0
* `testimonialswidget_widget()` use `testimonials_slider()` instead as of 2.19.0
