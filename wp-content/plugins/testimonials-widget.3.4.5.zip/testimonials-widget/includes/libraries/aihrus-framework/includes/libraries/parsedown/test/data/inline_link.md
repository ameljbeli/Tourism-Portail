[link](http://example.com)

[link](/url-(parentheses)) with parentheses in URL 

([link](/index.php)) in parentheses

[`link`](http://example.com)

[![MD Logo](http://parsedown.org/md.png)](http://example.com)

[![MD Logo](http://parsedown.org/md.png) and text](http://example.com)