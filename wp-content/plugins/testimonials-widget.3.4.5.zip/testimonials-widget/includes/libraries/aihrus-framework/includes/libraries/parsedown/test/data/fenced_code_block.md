```
<?php

$message = 'fenced code block';
echo $message;
```

~~~
tilde
~~~

```php
echo 'language identifier';
```