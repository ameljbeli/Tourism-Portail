an [implicit] reference link

[implicit]: http://example.com

an [implicit][] reference link with an empty link definition

an [implicit][] reference link followed by [another][]

[another]: http://cnn.com

an [explicit][example] reference link with a title

[example]: http://example.com "Example"